Drag all files into the deadlock directory on steam (right click the deadlock steam icon and click "manage" -> "browse local files" to get there quickly)

When in deadlock, press f7 to open the console and type "map onelane"

If you want to play with bots, also type in the console "exec onelanebots". Otherwise, they will mostly break

To play with friends:
when in the map, type "status" in the console
in the steamid section, there should be a section like [A:1:111111111111111]
tell your friends to type "connect [A:1:111111111111111]" (replace the id section with what you have)
if that does not work try to use "-dev" in the deadlock launch options by right clicking deadlock in steam -> click properties -> go to launch options and type -dev

This Map also includes a vpk script mod to increase the amount of money split between players to make the game go faster. Located in the addons folder.

The mod makes the split from troopers 100/80/80/80/80/80% 
Camps give 1.2X extra value with slightly improved scaling overtime
Lane Guardians have -15% health
Walkers have +10% health
In base Guardians have +15% health
Hero kill gold share changed to 70/70/70/70/70/70

REMEMBER TO HAVE ALL PLAYERS MANUALLY DOWNLOAD THE MAP AND/OR MOD, EVEN IF YOU DOWNLOADED A PREVIOUS VERSION BEFORE

V1.8
-Overall file structure changed to now include a replacement gameinfo.gi to have the addon work out of the box and have the VPK addon automatically enabled.
	-You will NOT get banned for having the vpk enabled while in a normal match of Deadlock
-VPK addon changed
	-Trooper soul split is now 100/80/80/80/80/80% 
	-Hero kill soul split is 70% no matter what
	-Lane guardians have even less health (-15%)
-Fixed shop disabling for both teams when guardians die
-Fixed base side doors opening for both teams
-Lane guardians moved backwards to match normal game guardians