This is a "quick" install for the ARAM / One Lane map for deadlock.

It contains:

A one lane map
Soul share a lot higher - Means that you get a "normal" amount of souls per minion as you would split across multiple lanes


How to install:

Drop the folder next to this txt file **directly** next into your deadlock folder.

It contains a modified game info file to properly register the mods, please remove this if you have a custom setup gameinfo. 

It places the addons into your "addons" folder, so if you have a different mod folder name you may need to move things around.